#!/bin/sh
#
# TCP Listener - Installer
# @author Alex D. 
# @link https://www.upwork.com/o/profiles/users/_~0170b9b80bdefdcd81/
#
#
# chmod 0700 /home/ec2-user/listener/install/install && sudo /home/ec2-user/listener/install/install 
# chmod 0700 /opt/listener/install/install && /opt/listener/install/install 
 

SCRIPTDIR=$(cd `dirname $0` && pwd)
force=""
[ -n "$1" ]	&& force="-f"


if [ ! -f /usr/bin/reset-mcu ]; then
	echo "Run this installer only on OpenWRT !"
	exit 1
fi


	## This needs to run on boot
	mkdir -p /opt/listener
	mkdir -p /tmp/listener/log
	mkdir -p /tmp/listener/run

	ln -s /tmp/listener/log /opt/listener/ &> /dev/null
	ln -s /tmp/listener/run /opt/listener/ &> /dev/null







if ! id listener &> /dev/null; then

	opkg update > /dev/null
	opkg install socat nano

	echo " - Creating user listener"

fi



cd /opt/listener



## The default configuration file
if [ ! -f "conf/listen.conf" ]; then
	cp "$SCRIPTDIR/defaults.conf" conf/listen.conf &> /dev/null
fi


echo " - Setting Permissions"

chown -R root:root /opt/listener

cd /opt/listener

## all directories, recursively
find . -type d -exec chmod 750 {} \;

## all files, recursively
find . -type f -exec chmod 640 {} \;


chmod 0750 /opt/listener run log exec/listen install/install install/cron
chmod 0660 conf/listen.conf
rm -f exec/debug



### The demo script that can be called via HTTP to check the barcode
#echo " - Copy a demo PHP script to /var/www/html/"
#########################################################
#cp $force install/barcodeReceived.php /var/www/html/ &> /dev/null
#chmod 0644 /var/www/html/barcodeReceived.php
#chown root:www /var/www/html/barcodeReceived.php


# Listener no 1 on port 42001 - should be used by max 5 scanners
socat -s -d -d -L"/opt/listener/run/listener1.lock" TCP4-LISTEN:42001,reuseaddr,fork EXEC:/opt/listener/exec/listen,pty,ignbrk=0,echo=0 &>"/opt/listener/run/listener1.out" &


echo " [ ok ] TCP Listener Installed Sucessfully !"
########################################################
echo
