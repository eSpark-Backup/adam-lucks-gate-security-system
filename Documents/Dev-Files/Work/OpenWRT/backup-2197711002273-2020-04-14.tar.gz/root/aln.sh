#!/bin/sh
#
#   aln
#




    # global(s)
    script_name=$( basename $0 )

    # ignore
    ignore[0]='.git/'
    ignore[1]='README.md'
    ignore[2]='INSTALL'




    # | feature(s)

        function backup_path {

            # file
            file="$1"

            # ? - file - exists - and - not - symlink
            if [ -e "$file" ] && [ ! -L "$file" ]; then

                # path(s) - backup
                file_backup="$file.`date +%s`.bak"

                # ? - mv - backup - valid
                if mv "$file" "$file_backup"; then
                    stdout "mv '$file' '$file_backup'"
                else
                    return 1
                fi

            fi

            # return - valid
            return 0

        }

        function create_folder {

            # file
            file="$1"

            # ? - file - not - exists - and - not symlink - and - not directory
            if [ ! -e "$file" ] && [ ! -L "$file" ] && [ ! -d "$file" ]; then

                # path(s) - folder
                folder="`dirname "$file"`"

                # ? - create - folder - valid
                if mkdir -p "$folder"; then
                    stdout "mkdir -p '$folder'"
                else
                    return 1
                fi

            fi

            # return - valid
            return 0

        }

        function create_symlink {

            # ? - symlink - valid
            if ln -sf "$1" "$2"; then
                stdout "ln -sf '$1' '$2'"
            else
                return 1
            fi

            # return - valid
            return 0

        }

        function valid_path {

            # iterate - ignore - strings
            for i in "${ignore[@]}"; do

                # ? - match - ignore
                if [[ "$1" == *"$i"* ]]; then
                    return 1
                fi

            done

            # return - valid
            return 0

        }

    # feature(s) |


    # | stdout/stderr

        function stderr {
            echo "Error: $@"
        }

        function stdout {
            echo "$@"
        }

        function usage {
            echo "$script_name usage: $script_name [-s|--source path] [-d|--destination path]"
        }

    # stdout/stderr |


    # | main

        # check - arg(s)
        [ $# -eq 0 ] && usage && exit

        # arg(s)
        while [[ $# -gt 0 ]]
        do
            case "$1" in
                -d|--destination)   dst="$2"
                                    shift
                                    shift
                                    ;;
                -h)                 usage
                                    exit 2
                                    ;;
                -s|--source)        src="$2"
                                    shift
                                    shift
                                    ;;
                *)                  usage
                                    exit 2
                                    ;;
            esac
        done

        # check - path(s)
        [ ! -d "$src" ] && stderr "'$src' not found." && exit 2
        [ ! -d "$dst" ] && stderr "'$dst' not found." && exit 2

        # realpath - path(s)
        src=$( realpath "$src" )
        dst=$( realpath "$dst" )

        # ? - dst - root
        if [[ "$dst" = "/" ]]; then dst=""; fi

        # | aln
        for f in `find "$src" -type f`; do

            # path(s)
            src_file=$( realpath $f )
            dst_file="$dst""/${src_file#$src/}"

            # ? - valid - path
            if ! valid_path "$src_file"; then
                continue
            fi

            # create - folder
            create_folder "$dst_file"

            # create - symlink
            create_symlink "$src_file" "$dst_file"

        done
        # aln |

    # main |




#
#   %(#.0)?-
#
