#!/bin/sh
#
# /root/init.sh force






ifname=`uci get network.lte.ifname 2>/dev/null`
if [ -n "$ifname" -a -f /root/config -a "$1" != "force" ]; then
	echo "Already initiated.. $ifname .. Exiting.."
	exit 0
fi


if [ ! -f /root/config ]; then	
	cp -f /root/config.def /root/config
fi
. /root/config


echo "Init Script - DEBUG:$DEBUG UniqueID:$UniqueID"


echo " - Setting Permissions"
chmod 0777 /root/*.sh
chmod 0777 /www/cgi-bin/api/*


#	mkdir -p /opt/listener
#	ln -s /tmp/listener/log /opt/listener/ &> /dev/null
#	ln -s /tmp/listener/run /opt/listener/ &> /dev/null



if [ ! -d /tmp/opkg-lists ] && [ ! -f /etc/usb-mode.json -o ! -f /etc/config/mwan3 ]; then	

	if [ ! -f /usr/bin/reset-mcu  ]; then
		PingIP="downloads.arduino.cc"
	else 
		PingIP="openwrt.com"
	fi

	tries=0
	while [[ $tries -lt 5 ]]; do
		if /bin/ping -c 1 $PingIP &>/dev/null; then

			echo " - running opkg update"
			opkg update > /dev/null
			[ "$?" != "0" ] && echo "[ERROR] Unable to run opkg update" && exit 1


			echo " - installing critical packages"
			opkg install kmod-usb-net-cdc-ether usb-modeswitch mwan3 socat curl > /dev/null
			[ "$?" != "0" ] && echo "[ERROR] Unable to install critical packages" && exit 1
			#mwan3 start

			echo " - installing storage packages"
			opkg install kmod-fs-f2fs f2fs-tools kmod-usb-storage block-mount coreutils-realpath > /dev/null
			[ "$?" != "0" ] && echo "[ERROR] Unable to install storage packages" && exit 1

			echo " - installing imaging packages"
			# opkg --add-dest sd:/mnt/sda1
			#opkg --add-dest sd:/mnt/sda1 -d sd install motion ffmpeg > /dev/null

/root/aln.sh -s /mnt/sda1/etc/ -d /etc/
/root/aln.sh -s /mnt/sda1/lib/ -d /lib/
/root/aln.sh -s /mnt/sda1/usr/ -d /usr/


			
			if [ ! -f /usr/bin/reset-mcu  ]; then
				# opkg install usbutils
				#  mkfs.f2fs /dev/sda1
				# block detect | uci import fstab
				# uci set fstab.@mount[-1].enabled='1'
				# uci set fstab.@global[0].check_fs='1'
				# uci commit
				#			else
				opkg install nano luci-app-mwan3 gdisk > /dev/null
			fi
			
			
			if [ "$DEBUG" != "1" ]; then
				echo " - rebooting"
				reboot
			fi
			exit 0
		fi
		
		tries=$((tries+1))
		echo " - retrying to ping $PingIP : $tries"
		sleep 2
		
	done
	echo "[ERROR] Unable to connect to the internet" 
	exit 1	

fi


echo " - uci config"
uci batch << EOF
set network.wan.metric='10'
set network.wan.ipv6='auto'

set network.lte='interface'
set network.lte.ifname='eth1'
set network.lte.proto='dhcp' 
set network.lte.metric='20' 
set network.lte.ipv6=1

set system.ntp.enable_server=1
EOF


if [ -f /usr/bin/reset-mcu  ]; then
	uci set network.lte.ifname='eth2'
	### BAD add_list firewall.@zone[1].network='lte'
fi

 

uci commit
sync
luci-reload

/etc/init.d/firewall restart > /dev/null
/etc/init.d/network restart > /dev/null

