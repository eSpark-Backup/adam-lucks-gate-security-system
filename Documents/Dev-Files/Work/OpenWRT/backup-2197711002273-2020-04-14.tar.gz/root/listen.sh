#!/bin/sh
#
# TCP Listener - looping script
# This script is executed on each NEW connection
#
# @author Alex D. 
# @link https://www.upwork.com/o/profiles/users/_~0170b9b80bdefdcd81/
#
#
# socat -v TCP4-LISTEN:42001,reuseaddr,fork EXEC:/root/listen.sh,pty,ignbrk=0,echo=0
# nc 127.0.0.1 42001
# 
# See a list of connected scanners:
#> find /tmp/listener/run/ -type f -name '*.pid'  -print 2>/dev/null
#> find /tmp/listener/run/ -type f -name '*.pid'
#
# Disconnect all scanners (they will reconnect in max 3 minutes)
#> killall socat
# 
#See the last data sent by scanner 1
#> tail '/opt/listener/log/Scanner1.log'


cd "/tmp"

## Default values
desc=''
VER='0.5'
RELAY_TRIGGER_SECONDS="10"
MESSAGE=''
IDENTIFIER=''

#######################################################



### New connection
### This should be the device identifier: Scanner N
read -t 5 IDENTIFIER

## Strips Whitespace and other undesired characters
IDENTIFIER=${IDENTIFIER//[^[:alnum:]]/}
[ -z "$IDENTIFIER" ] && exit 1;

## Validate the identifier
scn=${IDENTIFIER:0:7}
if [ "$scn" != "Scanner" ]; then	
	echo "BYE"
	exit 1
fi

LOGF="/tmp/listener/log/$IDENTIFIER.log"
ENVF="/tmp/listener/log/$IDENTIFIER.env"
PIDF="/tmp/listener/run/$IDENTIFIER.pid"


## Is the same identifier already connected?
if [ -f "$PIDF" ]; then	
	## Collision: A scanner with the same identifier is already connected! 
	## It might be a dead connection. We need to wait for that connection to close
	TIMESTAMP=`date "+%Y-%m-%d %H:%M:%S"`
	echo "[$TIMESTAMP] > < $IDENTIFIER" >> "/tmp/listener/COLLISIONS.log"
	sleep 15
	echo "BYE"
	exit 1
fi



#######################################################



## Sends commands back
function sendCmd(){
	cmd="$@"
	cmd=${cmd//[[:blank:]]/}
	if [ "$cmd" = "%" ]; then
		printf "%%\r"	
	else
		printf "$cmd\r"
	fi
	if [ -z "$desc" ]; then		
		echo "<< $cmd" >> $LOGF
	else 		
		echo "<< $cmd   ( $desc )" >> $LOGF
	fi
	MESSAGE=''
	read -t 15 MESSAGE
	MESSAGE=${MESSAGE//[^[:alnum:] ._-]/}
	if [ -z "$MESSAGE" -o "$MESSAGE" = "NOK" ]; then
		echo "   >> [FAIL] $cmd" >> $LOGF
	else		
		echo " >> $MESSAGE" >> $LOGF
	fi
}


function lockExitTrap () {
	#Don't recurse in the exit trap
	trap - INT TERM EXIT
	#remove the pid file cleanly on exit
	rm -f "$1" &> /dev/null
	exit
}



## The number of seconds the relay will be triggered
## This is a STRING with exactly 2 characters like "02"
RELAY_TRIGGER_SECONDS="80"





## This function processes the received barcode string
####################################################################################
## Calling an external script or an API URL is a huge overhead!
function qrCodeReceived(){

	## Sanitize: Strip non-alphanumeric chars from the first argument
	export qrCode=${1//[^[:alnum:]]/} 	

	## Get scanner integer ID
	export ScannerId=${2//[^[:digit:]]/}


	/root/control.sh qrcode "$qrCode" "$ScannerId" &> /dev/null
	
	if [ "$?" != "0" ]; then
		echo "Rejected" >> $LOGF	
		return 1 
	fi
	

	### Since we got here, it means the barcode is valid.
	######################################################
	desc=''
	echo "The barcode is valid! Sending response back to the scanner: Turn the relay on for $RELAY_TRIGGER_SECONDS seconds" >> $LOGF

	## "Turns the relay on for xx seconds"
	#sendCmd "!$RELAY_TRIGGER_SECONDS"

	## "Turns the speaker on for xx * 10ms"
	#sendCmd "&80"
	
	## "Blinks the bicolor led for xx seconds, then leaves it off"
	#sendCmd "($RELAY_TRIGGER_SECONDS"

	## Sends all 3 commands above at once
	sendCmd "!$RELAY_TRIGGER_SECONDS\r&80\r($RELAY_TRIGGER_SECONDS"
}




## This functions are triggered when a sensor changes it`s state
####################################################################################


#>:S1C Sense Input 1 Low	= BLACK +++ Blue
function sensorEventS1C(){

	## "Turns the speaker on for xx * 10ms"
	sendCmd "&11"
}

#>:S1O Sense Input 1 High	= BLACK < > Blue
function sensorEventS1O(){

	## "Turns the speaker on for xx * 10ms"
	sendCmd "&10"	
}


#>:S2C Sense Input 2 Low	= WHITE +++ Blue
function sensorEventS2C(){

	## "Turns the speaker on for xx * 10ms"
	sendCmd "&21"		
}

#>:S2O Sense Input 2 High	= WHITE < > Blue
function sensorEventS2O(){

	## "Turns the speaker on for xx * 10ms"
	sendCmd "&20"		
}





## Init
################################################################


## Clear the log file
## One file per scanner, cleared on each connect
echo "$IDENTIFIER" > $LOGF
TIMESTAMP=`date "+%Y-%m-%d %H:%M:%S"`
echo "[$TIMESTAMP] - Listener Version $VER" >> $LOGF

## Save the env for debuging
env > "$ENVF"

## Save the PID 
echo "$$" > "$PIDF"

## Deletes the PIDF on exit
trap "{ lockExitTrap \"\$PIDF\" ; }" INT TERM EXIT



## Blinks the bicolor led for xx seconds
sendCmd "(05"


#### Listener Loop
################################################################
while true
do
	## Now listen for any messages
	MESSAGE=''
	read -t 100 MESSAGE
	MESSAGE=${MESSAGE//[^[:alnum:] ._-]/}
	if [ -n "$MESSAGE" ]; then
		
		TIMESTAMP=`date "+%Y-%m-%d %H:%M:%S"`
		echo "[$TIMESTAMP] >>>> $MESSAGE" >> $LOGF

		case "$MESSAGE" in

			bye|BYE)
				echo "BYE"
				exit 0
			;;

			ver|VER)
				sendCmd "$VER"
			;;

			#>:S1C Sense Input 1 Low	= BLACK +++ Blue
			S1C)
				sensorEventS1C
			;;

			#>:S1O Sense Input 1 High	= BLACK < > Blue
			S1O)
				sensorEventS1O
			;;

			#>:S2C Sense Input 2 Low	= WHITE +++ Blue
			S2C)
				sensorEventS2C
			;;

			#>:S2O Sense Input 2 High	= WHITE < > Blue
			S2O)
				sensorEventS2O
			;;

			## $MESSAGE is a BARCODE
			*) 

				## Sanitize the qrCode (numbers only):				
				qrCode=${MESSAGE//[^[:digit:]]/}
				if [ "$qrCode" = "$MESSAGE" ] && [ -n "$qrCode" ]; then					
					qrCodeReceived "$MESSAGE" "$IDENTIFIER"
				fi


			;;
		esac

	else

		## Send a bogus command to check if the scanner is still online		
		printf "V\r"
		MESSAGE=''
		read -t 3 MESSAGE
		MESSAGE=${MESSAGE//[^[:alnum:] ._-]/}
		if [ -z "$MESSAGE" ]; then
			TIMESTAMP=`date "+%Y-%m-%d %H:%M:%S"`
			echo "[$TIMESTAMP] Offline!" >> $LOGF
			echo "Disconnecting $IDENTIFIER" >> $LOGF
			echo "Offline!"
			exit 1
		fi


	fi

done












exit 0
